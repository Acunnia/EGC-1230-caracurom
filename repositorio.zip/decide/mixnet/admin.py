from django.contrib import admin

from .models import Mixnet


admin.site.register(Mixnet)
