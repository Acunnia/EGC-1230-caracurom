from django.apps import AppConfig


class CensusConfig(AppConfig):
    name = 'census'
